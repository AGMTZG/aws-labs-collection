console.log("JavaScript successfully loaded from S3!");
